
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ericz99',
  applicationName: 'serverless-covid19',
  appUid: 'WDl9NnL0cmw5bc7xnN',
  orgUid: 'KmmF9rdxWWk5QZjq7z',
  deploymentUid: '7071f8d3-e1f8-473f-85bc-220cbc62c7d8',
  serviceName: 'covid-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.15',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'covid-api-dev-app', timeout: 10 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}